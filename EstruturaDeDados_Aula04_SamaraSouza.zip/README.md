# Estrutura de Dados - Aula 04
**Professora:** Samara Souza  

## Exercícios

### 1️⃣ Desfazer (Ctrl + Z)
Utiliza uma pilha, pois as ações são desfeitas na ordem inversa à que ocorreram.

### 2️⃣ Organização de Exames
Usa uma pilha para imprimir os exames na ordem inversa à realização.

### 3️⃣ Controle de Tarefas (Fila e Pilha)
As tarefas comuns ficam na fila (FIFO) e as prioritárias na pilha (LIFO).

### 4️⃣ Classe Pilha (Arrays)
Implementa métodos `push`, `pop`, `peek` e `isEmpty`.

### 5️⃣ Classe Fila (Arrays)
Implementa métodos `enqueue`, `dequeue`, `peek` e `isEmpty`.

### 6️⃣ Pilha e Fila com LinkedList
Demonstra o uso das estruturas nativas do Java.
