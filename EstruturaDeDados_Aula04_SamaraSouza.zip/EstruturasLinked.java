import java.util.LinkedList;
public class EstruturasLinked {
    public static void main(String[] args) {
        LinkedList<Integer> pilha = new LinkedList<>();
        pilha.push(1);
        pilha.push(2);
        pilha.push(3);
        System.out.println("Desempilhando:");
        while (!pilha.isEmpty()) {
            System.out.println(pilha.pop());
        }
        LinkedList<Integer> fila = new LinkedList<>();
        fila.offer(1);
        fila.offer(2);
        fila.offer(3);
        System.out.println("Desenfileirando:");
        while (!fila.isEmpty()) {
            System.out.println(fila.poll());
        }
    }
}