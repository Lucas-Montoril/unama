import java.util.Stack;
public class Exercicio2_Hospital {
    public static void main(String[] args) {
        Stack<String> exames = new Stack<>();
        exames.push("Exame 1");
        exames.push("Exame 2");
        exames.push("Exame 3");
        while (!exames.isEmpty()) {
            System.out.println("Imprimindo: " + exames.pop());
        }
    }
}