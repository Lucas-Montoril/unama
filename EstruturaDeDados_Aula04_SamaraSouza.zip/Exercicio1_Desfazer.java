public class Exercicio1_Desfazer {
    public static void main(String[] args) {
        java.util.Stack<String> acoes = new java.util.Stack<>();
        acoes.push("Digitar A");
        acoes.push("Digitar B");
        acoes.push("Apagar A");
        while (!acoes.isEmpty()) {
            System.out.println("Desfazendo: " + acoes.pop());
        }
    }
}