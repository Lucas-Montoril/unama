public class Fila {
    private int[] elementos;
    private int frente;
    private int tras;
    private int tamanho;
    private int capacidade;

    public Fila(int capacidade) {
        this.capacidade = capacidade;
        this.elementos = new int[capacidade];
        this.frente = 0;
        this.tras = -1;
        this.tamanho = 0;
    }

    public void enqueue(int valor) {
        if (tamanho == capacidade) {
            System.out.println("Fila cheia!");
        } else {
            tras = (tras + 1) % capacidade;
            elementos[tras] = valor;
            tamanho++;
        }
    }

    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Fila vazia!");
            return -1;
        }
        int valor = elementos[frente];
        frente = (frente + 1) % capacidade;
        tamanho--;
        return valor;
    }

    public int peek() {
        if (isEmpty()) {
            System.out.println("Fila vazia!");
            return -1;
        }
        return elementos[frente];
    }

    public boolean isEmpty() {
        return tamanho == 0;
    }

    public static void main(String[] args) {
        Fila fila = new Fila(5);
        fila.enqueue(10);
        fila.enqueue(20);
        fila.enqueue(30);
        System.out.println("Primeiro da fila: " + fila.peek());
        while (!fila.isEmpty()) {
            System.out.println("Removendo: " + fila.dequeue());
        }
    }
}