import java.util.*;
public class Exercicio3_FilaPilha {
    public static void main(String[] args) {
        Queue<String> fila = new LinkedList<>();
        Stack<String> pilha = new Stack<>();
        fila.offer("Tarefa 1");
        fila.offer("Tarefa 2");
        pilha.push("Tarefa Prioritária A");
        pilha.push("Tarefa Prioritária B");
        while (!pilha.isEmpty()) {
            System.out.println("Executando: " + pilha.pop());
        }
        while (!fila.isEmpty()) {
            System.out.println("Executando: " + fila.poll());
        }
    }
}