# POO - Aula 06
**Professora:** Samara Souza  

## Atividades

### 1️⃣ Herança: Pessoa, Professor, Funcionario e Aluno
Implementa hierarquia de classes com atributos e métodos herdados.

### 2️⃣ Classe PessoaPacote
Cria uma classe Pessoa com atributos encapsulados e múltiplos construtores.

### 3️⃣ Subclasse Fornecedor
Extende PessoaPacote e adiciona atributos valorCredito e valorDivida, com método obterSaldo().

### 4️⃣ Classe Veiculo e Subclasses
Implementa Veiculo, Carro e Moto com o método exibirInfo() e demonstração no main.
