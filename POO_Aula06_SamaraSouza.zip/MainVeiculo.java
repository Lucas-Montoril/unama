public class MainVeiculo {
    public static void main(String[] args) {
        Veiculo[] veiculos = new Veiculo[2];
        veiculos[0] = new Carro("Toyota", "Corolla", 4);
        veiculos[1] = new Moto("Honda", "CB500", 500);
        for (Veiculo v : veiculos) {
            v.exibirInfo();
        }
    }
}