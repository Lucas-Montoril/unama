package exercicio5;

public class Main {
    public static void main(String[] args) {
        Carro carro1 = new Carro();
        carro1.marca = "Toyota";
        carro1.modelo = "Corolla";
        carro1.ano = 2020;

        Carro carro2 = new Carro();
        carro2.marca = "Honda";
        carro2.modelo = "Civic";
        carro2.ano = 2019;

        carro1.mostrarInfo();
        carro1.ligar();

        carro2.modelo = "HRV";
        carro2.mostrarInfo();
        carro2.ligar();
    }
}
