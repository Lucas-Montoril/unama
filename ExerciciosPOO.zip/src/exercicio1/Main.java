package exercicio1;

public class Main {
    public static void main(String[] args) {
        Livro livro1 = new Livro();
        livro1.titulo = "Java Básico";
        livro1.autor = "José da Silva";
        livro1.preco = 50.0;

        Livro livro2 = new Livro();
        livro2.titulo = "POO Avançada";
        livro2.autor = "Maria Souza";
        livro2.preco = 80.0;

        livro1.mostrarInfo();
        livro2.mostrarInfo();

        livro2.aplicarDesconto(10);
        System.out.println("Preço com desconto: " + livro2.preco);

        Cliente cliente = new Cliente();
        cliente.nome = "Carlos";
        cliente.idade = 25;
        cliente.email = "carlos@email.com";

        cliente.mostrarDados();
        cliente.comprarLivro(livro1);
    }
}
