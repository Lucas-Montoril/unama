package exercicio1;

public class Cliente {
    String nome;
    int idade;
    String email;

    void mostrarDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Email: " + email);
    }

    void comprarLivro(Livro livro) {
        System.out.println(nome + " comprou o livro: " + livro.titulo);
    }
}
