package exercicio3;

public class Aluno {
    String nome;
    int matricula;
    double notaAv1;
    double notaAv2;

    void mostrarDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Matrícula: " + matricula);
        System.out.println("Nota Av1: " + notaAv1);
        System.out.println("Nota Av2: " + notaAv2);
    }

    double calcularMedia() {
        return (notaAv1 + notaAv2) / 2;
    }

    void verificarAprovacao() {
        double media = calcularMedia();
        if (media >= 7) {
            System.out.println(nome + " está aprovado! Média: " + media);
        } else {
            System.out.println(nome + " está reprovado! Média: " + media);
        }
    }
}
