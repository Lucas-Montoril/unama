package exercicio3;

public class Main {
    public static void main(String[] args) {
        Aluno aluno1 = new Aluno();
        aluno1.nome = "Carlos";
        aluno1.matricula = 123;
        aluno1.notaAv1 = 6.0;
        aluno1.notaAv2 = 8.0;

        Aluno aluno2 = new Aluno();
        aluno2.nome = "Ana";
        aluno2.matricula = 456;
        aluno2.notaAv1 = 7.5;
        aluno2.notaAv2 = 9.0;

        aluno1.mostrarDados();
        aluno1.verificarAprovacao();

        aluno2.mostrarDados();
        aluno2.verificarAprovacao();
    }
}
