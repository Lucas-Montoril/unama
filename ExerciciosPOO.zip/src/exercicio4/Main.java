package exercicio4;

public class Main {
    public static void main(String[] args) {
        ContaBancaria conta1 = new ContaBancaria();
        conta1.numeroConta = "001";
        conta1.titular = "João";
        conta1.saldo = 100;

        ContaBancaria conta2 = new ContaBancaria();
        conta2.numeroConta = "002";
        conta2.titular = "Maria";
        conta2.saldo = 200;

        conta1.depositar(50);
        conta1.consultarSaldo();

        conta2.sacar(100);
        conta2.consultarSaldo();
    }
}
